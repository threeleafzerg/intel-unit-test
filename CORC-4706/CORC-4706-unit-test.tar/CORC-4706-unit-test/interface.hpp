
#include <CL/sycl.hpp>

int run_test_a(int v, cl::sycl::queue &deviceQueue);
int run_test_b(int v, cl::sycl::device &device);
