//==------ builtins.hpp - Non-standard SYCL built-in functions -------------==//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#pragma once


#ifdef __SYCL_DEVICE_ONLY__
#define CONSTANT_AS __attribute__((opencl_constant))
// Note: __format string is declared in constant address space to be compatible
// with OpenCL C
extern int __spirv_ocl_printf(const CONSTANT_AS char *__format, ...);
#else
#define CONSTANT_AS
#endif

namespace cl {
namespace sycl {
namespace intel {
namespace experimental {

// Provides functionality to print data from kernels in a C way:
// - On non-host devices this function is directly mapped to printf from
//   OpenCL C
// - On host device, this function should be equivalent to standard printf
//   function from C/C++.
//
// Please refer to corresponding section in OpenCL C specification to find
// information about format string and its differences from standard C rules.
//
// This function is placed under 'experimental' namespace on purpose, because it
// has too much caveats you need to be aware of before using it. Please find
// them below and read carefully before using it:
//
// - According to the OpenCL spec, the format string must be
// resolvable at compile time i.e. cannot be dynamically created by the
// executing program.
//
// - According to the OpenCL spec, the format string must reside in constant
// address space. This requires to perform "tricky" declarations of them, see
// test/built-ins/printf.cpp for examples
// FIXME: this potentially can be done on SYCL FE side automatically
//
// - The format string is interpreted according to the OpenCL C spec, where all
// data types has fixed size, opposed to C++ types which doesn't guarantee
// the exact width of particular data types (except, may be, char). This might
// lead to unexpected result, for example: %ld in OpenCL C means that printed
// argument has 'long' type which is 64-bit wide by the OpenCL C spec. However,
// by C++ spec long is just at least 32-bit wide, so, you need to ensure (by
// performing a cast, for example) that if you use %ld specifier, you pass
// 64-bit argument to the cl::sycl::experimental::printf
//
// - OpenCL spec defines several additional features, like, for example, 'v'
// modifier which allows to print OpenCL vectors: note that these features are
// not available on host device and therefore their usage should be either
// guarded using __SYCL_DEVICE_ONLY__ preprocessor macro or avoided in favor
// of more portable solutions if needed
//
template <typename... Args>
int printf(const CONSTANT_AS char *__format, Args... args) {
#ifdef __SYCL_DEVICE_ONLY__
  return __spirv_ocl_printf(__format, args...);
#else
  return ::printf(__format, args...);
#endif
}

} // namespace experimental
} // namespace intel
} // namespace sycl
} // namespace cl

#undef CONSTANT_AS
