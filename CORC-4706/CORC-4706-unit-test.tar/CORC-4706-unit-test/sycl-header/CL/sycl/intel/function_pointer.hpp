//==----------- function_pointer.hpp --- SYCL Function pointers ------------==//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#pragma once

#include <CL/sycl/device.hpp>
#include <CL/sycl/program.hpp>
#include <CL/sycl/stl.hpp>

#include <type_traits>

__SYCL_INLINE namespace cl {
namespace sycl {
namespace intel {

// This is a preview extension implementation, intended to provide early access
// to a feature for review and community feedback.
//
// Because the interfaces defined by this header file are not final and are
// subject to change they are not intended to be used by shipping software
// products. If you are interested in using this feature in your software
// product, please let us know!

using device_func_ptr_holder_t = cl::sycl::cl_ulong;

/// \brief this function performs a cast from device_func_ptr_holder_t type
/// to the provided function pointer type.
template <
    class FuncType,
    typename FuncPtrType = typename std::add_pointer<FuncType>::type,
    typename std::enable_if<std::is_function<FuncType>::value, int>::type = 0>
inline FuncPtrType to_device_func_ptr(device_func_ptr_holder_t FptrHolder) {
  return reinterpret_cast<FuncPtrType>(FptrHolder);
}

template <class FuncType>
using enable_if_is_function_pointer_t = typename std::enable_if<
    std::is_pointer<FuncType>::value &&
        std::is_function<typename std::remove_pointer<FuncType>::type>::value,
    int>::type;

/// \brief this function can be used only on host side to obtain device function
/// pointer for the specified function.
///
/// \param F - pointer to function to make it work for SYCL Host device
/// \param FuncName - name of the function. Please note that by default names of
/// functions are mangled since SYCL is a C++. To avoid the need ot specifying
/// mangled name here, use `extern "C"`
/// \param P - sycl::program object which will be used to extract device
/// function pointer
/// \param D - sycl::device object which will be used to extract device
/// function pointer
///
/// \returns device_func_ptr_holder_t object which can be used inside a device
/// code. This object must be converted back to a function pointer using
/// `to_device_func_ptr` prior to actual usage.
///
/// Returned value is valid only within device code which was compiled for the
/// specified program and device. Returned value invalidates whenever program
/// is released or re-built
template <class FuncType, enable_if_is_function_pointer_t<FuncType> = 0>
device_func_ptr_holder_t get_device_func_ptr(FuncType F, const char *FuncName,
                                             program &P, device &D) {
  // TODO: drop function name argument and map host function pointer directly to
  // a device function pointer
  if (D.is_host()) {
    return reinterpret_cast<device_func_ptr_holder_t>(F);
  }

  if (program_state::linked != P.get_state()) {
    throw invalid_parameter_error(
        "Program must be built before passing to get_device_func_ptr");
  }

  device_func_ptr_holder_t FPtr = 0;
  // FIXME: return value must be checked here, but since we cannot yet check
  // if corresponding extension is supported, let's silently ignore it here.
  PI_CALL(piextGetDeviceFunctionPointer)(
      detail::pi::cast<pi_device>(detail::getSyclObjImpl(D)->getHandleRef()),
      detail::pi::cast<pi_program>(detail::getSyclObjImpl(P)->getHandleRef()),
      FuncName, &FPtr);

  return FPtr;
}

} // namespace intel
} // namespace sycl
} // namespace cl
