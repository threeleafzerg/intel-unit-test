
#include <CL/sycl.hpp>

int run_test_a(int v, cl::sycl::queue &deviceQueue);
