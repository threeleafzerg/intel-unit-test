
rm -f *.o 
rm -f libuser.a
rm -f a.out
